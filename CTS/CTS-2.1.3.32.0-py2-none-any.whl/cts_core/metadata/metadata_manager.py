"""
 * @section LICENSE
 *
 * @copyright
 * Copyright (c) 2016 Intel Corporation
 *
 * @copyright
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * @copyright
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * @copyright
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @section DESCRIPTION
"""

from cts_core.metadata.metadata_container import MetadataContainer, EnumType
from cts_core.metadata.model.entity import Entity
from cts_core.metadata.model.metadata_types import ComplexType
from cts_core.metadata.model.metadata_types import TypeDefinition
from cts_framework.commons.commons import Commons

TYPE_DEFINITION = "typedefinition"
COMPLEX_TYPE = "complextype"
ENUM_TYPE = "enumtype"
SCHEMA = "schema"
NAMESPACE = "namespace"
ENTITY_TYPE = "entitytype"
TERM = "term"


class MetadataManager:
    def __init__(self, ignore_types=None, map_types=None):
        self.ignore_types = ignore_types if ignore_types is not None else set()
        self.map_types = map_types if map_types is not None else dict()

    def read_metadata(self, qualifiers, *metadata):
        """
        :type metadata_text: str
        :rtype: cts_core.metadata.metadata_container.MetadataContainer
        """
        metadata_container = MetadataContainer(ignore_types=self.ignore_types, map_types=self.map_types)

        for metadata_text in metadata:
            metadata_soup = Commons.text_to_soup(metadata_text)
            for schema in metadata_soup.find_all(SCHEMA):
                metadata_container = self._process_namespace(schema, metadata_container, qualifiers)

        return metadata_container

    def _process_namespace(self, schema, metadata_container, qualifiers):
        """
        :type schema: bs4.element.Tag
        :type metadata_container: cts_core.metadata.metadata_container.MetadataContainer
        :rtype: cts_core.metadata.metadata_container.MetadataContainer
        """
        try:
            namespace_name = schema[NAMESPACE]
        except KeyError:
            print "WARNING::Incorrect schema definition {schema_definition},\n missing of namespace name".format(
                schema_definition=str(schema))
            return metadata_container

        for entity_soup in schema.find_all(ENTITY_TYPE):
            entity = Entity(metadata_container, namespace_name, entity_soup, qualifiers)
            metadata_container.entities[entity.name] = entity

        for type_soup in schema.find_all(ENUM_TYPE):
            enum_type = EnumType(metadata_container, namespace_name, type_soup, qualifiers)
            metadata_container.types[enum_type.name] = enum_type

        for type_soup in schema.find_all(COMPLEX_TYPE):
            complex_type = ComplexType(metadata_container, namespace_name, type_soup, qualifiers)
            metadata_container.types[complex_type.name] = complex_type

        for type_soup in schema.find_all(TYPE_DEFINITION):
            type_definition = TypeDefinition(metadata_container, namespace_name, type_soup, qualifiers)
            metadata_container.types[type_definition.name] = type_definition

        return metadata_container
