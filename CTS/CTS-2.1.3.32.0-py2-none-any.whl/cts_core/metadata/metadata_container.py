"""
 * @section LICENSE
 *
 * @copyright
 * Copyright (c) 2016 Intel Corporation
 *
 * @copyright
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * @copyright
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * @copyright
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @section DESCRIPTION
"""
from functools import partial

from cts_core.metadata.model.metadata_types import EnumType, ComplexType, TypeDefinition
from cts_core.metadata.model.metadata_types.primitive_types.primitive_type import PrimitiveType

# this is not a dead code
from cts_core.metadata.model.metadata_types.primitive_types import *

class EntitiesContainer(dict):
    def __init__(self, type_mapping_func, *args, **kwargs):
        dict.__init__(self, *args, **kwargs)
        self.type_mapping_func = type_mapping_func

    def __getitem__(self, item):
        """
        :rtype: cts_core.metadata.model.entity.Entity
        """
        mapped_type = self.type_mapping_func(item)
        try:
            return dict.__getitem__(self, mapped_type)
        except KeyError as key:
            if item is not None:
                print "ERROR::Unknown entity type %s" % key
            raise KeyError(key)

class TypesContainer(dict):
    def __init__(self, type_mapping_func, *params, **kwargs):
        dict.__init__(self, *params, **kwargs)

        for primitive_type in PrimitiveType.PRIMITIVE_TYPES_LIST:
            primitive_type_instance = primitive_type()
            self[primitive_type_instance.name] = primitive_type_instance

        self.type_mapping_func = type_mapping_func

    def __getitem__(self, item):
        """
        :rtype: EnumType or ComplexType or TypeDefinition or PrimitiveType
        """
        mapped_type = self.type_mapping_func(item)
        try:
            return dict.__getitem__(self, mapped_type)
        except KeyError as key:
            if item is not None:
                print "ERROR::Unknown type %s" % key
            raise KeyError(key)


class MetadataContainer:
    def __init__(self, ignore_types=None, map_types=None):
        self._ignore_types = ignore_types if ignore_types is not None else set()
        self._map_types = map_types if map_types is not None else dict()

        mapping_func = partial(MetadataContainer.map_type, self)
        self.entities = EntitiesContainer(type_mapping_func=mapping_func)
        self.types = TypesContainer(type_mapping_func=mapping_func)

    def _print_entities(self):
        print "DEBUG::Known Entity Types:"
        for key in sorted(self.entities.iterkeys()):
            print "DEBUG::\t%s" % key

    def print_types(self):
        self._print_entities()
        print "DEBUG::Other types:"
        for key in sorted(self.types.iterkeys()):
            print "DEBUG::\t%s" % key

    def to_be_ignored(self, *types):
        for type in types:
            if type in self._ignore_types:
                print "WARNING::User declared to skip validation of type %s" % type
                return True
        return False

    def map_type(self, type):
        if type in self._map_types:
            mapped_type = self._map_types[type]
            print "WARNING::User declared to use %s to validate %s" \
                  % (mapped_type, type)
            return mapped_type
        return type

    def get_type_definition(self, type_name):
        if type_name in self.types:
            return self.types[type_name]
        if type_name in self.entities:
            return self.entities[type_name]
        raise KeyError(type_name)
