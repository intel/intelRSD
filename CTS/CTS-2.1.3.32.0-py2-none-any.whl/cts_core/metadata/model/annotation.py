"""
 * @section LICENSE
 *
 * @copyright
 * Copyright (c) 2016-2017 Intel Corporation
 *
 * @copyright
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * @copyright
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * @copyright
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @section DESCRIPTION
"""

import copy

import collections

TERM = "term"
QUALIFIER = "qualifier"

DynamicPropertyPattern = collections.namedtuple('DynamicPropertyPattern', ['pattern', 'type'])

class Annotation:
    ADDITIONAL_PROPERTIES = "OData.AdditionalProperties"
    DYNAMIC_PROPERTY_PATTERNS = "Redfish.DynamicPropertyPatterns"
    PATTERN = "Pattern"
    TYPE = "Type"

    def __init__(self, annotation_soup):
        """
        :type annotation_soup: bs4.element.Tag

        """
        self.term = None
        self.qualifier = None
        self.value = None
        self.value_type = None
        self.dynamic_property_patterns = []

        try:
            annotations_attributes_list = copy.deepcopy(annotation_soup.attrs)
            self.term = annotations_attributes_list.pop(TERM, None)
            self.qualifier = annotations_attributes_list.pop(QUALIFIER, None)
            if self.term == Annotation.DYNAMIC_PROPERTY_PATTERNS:
                self.parse_dynamic_property_patterns(annotation_soup)
            else:
                self.value_type, self.value = annotations_attributes_list.items()[0]
        except IndexError:
            pass

    def parse_dynamic_property_patterns(self, annotation_soup):
        self.dynamic_property_patterns = []
        for collection in annotation_soup.find_all('collection'):
            for record in collection.find_all('record'):
                pattern = odata_type = None
                for propertyvalue in record.find_all('propertyvalue'):
                    try:
                        property = propertyvalue.attrs['property']
                        value = propertyvalue.attrs['string']

                        if property == Annotation.PATTERN:
                            pattern = value
                        elif property == Annotation.TYPE:
                            odata_type = value
                    except IndexError:
                        pass

                if pattern is not None and odata_type is not None:
                    self.dynamic_property_patterns.append(DynamicPropertyPattern(pattern, odata_type))
