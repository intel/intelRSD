"""
 * @section LICENSE
 *
 * @copyright
 * Copyright (c) 2016 Intel Corporation
 *
 * @copyright
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * @copyright
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * @copyright
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @section DESCRIPTION
"""
from copy import deepcopy
from cts_core.metadata.commons import Commons
from cts_core.metadata.model.metadata_model import MetadataModel
from cts_core.validation.validation_status import ValidationStatus

NAME = "name"
TYPE = "type"
NULLABLE = "nullable"
COLLECTION = "Collection("
ALLOWABLE = "@Redfish.AllowableValues"


class PatchStatus:
    PATCHABLE = "patchable"
    NOT_DEFINED = "not defined"
    NOT_PATCHABLE = "not patchable"


class Property(MetadataModel):
    def __init__(self, metadata_container, namespace_name, property_soup, qualifiers=None):
        """
        :type metadata_container: cts_core.metadata.metadata_container.MetadataContainer
        :type namespace_name: str
        :type property_soup: bs4.element.Tag
        """
        MetadataModel.__init__(self, metadata_container, property_soup, qualifiers)

        self.name = property_soup[NAME]
        property_type = property_soup[TYPE]
        self.is_collection = property_type.startswith(COLLECTION) and property_type.endswith(")")
        property_type = property_type[len(COLLECTION):-1] if self.is_collection else property_type
        self.type = Commons.parse_type_name(property_type, namespace_name)
        self.nullable = property_soup.get(NULLABLE, "true").lower() == "true"

    @property
    def annotations(self):
        """
        :rtype: dict[str, cts_core.metadata.model.annotation.Annotation]
        """
        try:
            annotations = deepcopy(self.metadata_container.types[self.type].annotations)
            annotations.update(self._annotations)
        except KeyError:
            annotations = self._annotations

        return annotations

    @property
    def is_required(self):
        """
        :rtype: bool
        """
        return "Redfish.Required" in self._annotations

    @property
    def patch_status(self):
        """
        :rtype: bool
        """
        try:
            if self.annotations["OData.Permissions"].value == "OData.Permission/ReadWrite":
                return PatchStatus.PATCHABLE
            elif self.annotations["OData.Permissions"].value == "OData.Permission/Read":
                return PatchStatus.NOT_PATCHABLE
            else:
                print "WARNING::Unknown OData.Permissions for %s. value = %s. Property will not be patched." % \
                    (self.name, self.annotations["OData.Permissions"].value)
                return PatchStatus.NOT_DEFINED

        except KeyError:
            return PatchStatus.NOT_DEFINED

    def get_allowables(self, resource):
        try:
            allowable_values_property = self.name + ALLOWABLE
            allowable_values = resource[allowable_values_property]
            return allowable_values
        except KeyError:
            return []

    def validate(self, resource, path, annotations=None):
        """
        :type annotations: dict
        :type resource: dict
        :type path: str
        :rtype: str
        """
        if self.metadata_container.to_be_ignored(self.type):
            return ValidationStatus.PASSED

        resource_path = "->".join([path, self.name])
        try:
            property_value = resource[self.name]
        except KeyError:
            if self.is_required:
                print "ERROR::Required property {value_path} not present in the resource".format(
                    value_path=resource_path)
                return ValidationStatus.FAILED
            else:
                print "DEBUG::Optional property {value_path} is not present in the resource".format(
                    value_path=resource_path)
                return ValidationStatus.PASSED
        except TypeError:
            print "ERROR::Property %s is expected to be json object" % path
            return ValidationStatus.FAILED

        if property_value is None:
            if self.nullable:
                return ValidationStatus.PASSED
            else:
                print "ERROR::Property %s cannot be null" % resource_path
                return ValidationStatus.FAILED

        try:
            if self.is_collection:
                status = self._validate_collection(property_value, resource_path)
            else:
                status = self.metadata_container.types[self.type].validate(property_value, resource_path,
                                                                           self.annotations)

                allowable_values = self.get_allowables(resource)

                # is property value on "allowable values" list?
                if allowable_values and (not property_value in allowable_values):
                    print "WARNING::Property {resource_path} has value '{property_value}' that is not on the list of allowable values: {allowable_values_property}" \
                        .format(property_value=property_value, allowable_values_property=allowable_values, resource_path=resource_path)
                    status = ValidationStatus.join_statuses(status, ValidationStatus.PASSED_WITH_WARNINGS)

                # allowable list should contain only legal values
                for value in allowable_values:
                    allowable_value_status = \
                        self.metadata_container.types[self.type].validate(value, resource_path+ALLOWABLE,
                                                                          self.annotations)
                    status = ValidationStatus.join_statuses(status, allowable_value_status)


            return status
        except KeyError as err:
            print "ERROR::property {value_path} is defined to reference unknown type '{property_type}'. Error: {message}".format(
                value_path=resource_path, property_type=self.type, message=err.message)
            return ValidationStatus.FAILED

    def generate_values(self, property_annotations=None):
        """
        :type annotations: list [cts_core.metadata.model.annotation.Annotation]
        :rtype: list
        """
        #merge annotations from type definition with annotations from property definition
        annotations = deepcopy(self.metadata_container.types[self.type].annotations)
        annotations.update(property_annotations)
        return self.metadata_container.types[self.type].generate_values(annotations)

    def _validate_collection(self, property_value, resource_path):
        value_is_collection = True
        status = ValidationStatus.PASSED
        if isinstance(property_value, list):
            try:
                for path_element, resource_element in enumerate(property_value):
                    status = ValidationStatus.join_statuses(self.metadata_container.types[self.type].validate(
                        resource_element, "%s->%s" % (resource_path, path_element), self.annotations), status)
            except TypeError:
                value_is_collection = False
        else:
            value_is_collection = False

        if not value_is_collection:
            print "ERROR::Property {resource_path} is expected to be collection, but it is not" \
                .format(resource_path=resource_path)
            status = ValidationStatus.FAILED

        return status
