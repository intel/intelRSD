"""
 * @section LICENSE
 *
 * @copyright
 * Copyright (c) 2016 Intel Corporation
 *
 * @copyright
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * @copyright
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * @copyright
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @section DESCRIPTION
"""

import jsonrpclib

from gami_data_manager import GamiDataManager
from gami_resource import GamiResource


class GamiExplorer:
    def __init__(self, server_name):
        """
        Keyword arguments:
        server_name -- full server name including protocol and port number
        """
        self.json_server = jsonrpclib.Server(server_name)
        self.gami_data_manager = GamiDataManager()

    def get_resources_uuids(self, resource_name):
        resources_list = self._get_resources_list(resource_name)
        uuids = self._get_uuids_from_resource_list(resources_list)
        return list(set(uuids))

    def get_resource_info(self, resource_name, resource_uuid):
        resource = GamiResource(resource_name, resource_uuid)
        return self._get_resource_info(resource)

    def _get_resources_list(self, resource_name):
        """Find all resources with a given name.
        Return list of objects of type GamiResource
        """
        resources_list = list()
        managers_list = self._get_managers_list()
        if self.gami_data_manager.Constants.MANAGER == resource_name:
            resources_list = managers_list
        else:
            for manager in managers_list:
                resources_list += self._search_resource_tree(resource_name, manager)

        return list(set(resources_list))

    def _get_resource_info(self, resource):
        """Keyword arguments:
        resource -- GamiResource object
        """
        resource_name = resource.get_name()
        resource_uuid = resource.get_uuid()
        component_name = self.gami_data_manager.get_info_command_component_name(resource_name)
        get_info_command_name = self.gami_data_manager.get_info_command_name(resource_name)
        component_info = self._execute_command(get_info_command_name, **{component_name: resource_uuid})
        return component_info

    def _get_managers_list(self):
        get_manager_collection_command = self.gami_data_manager.Constants.GET_MANAGER_COLLECTION
        manager_resource_name = self.gami_data_manager.Constants.MANAGER
        manager_collection_key = self.gami_data_manager.Constants.MANAGER_COLLECTION_KEY

        raw_managers = self._execute_command(get_manager_collection_command)
        managers_list = []
        for raw_manager in raw_managers:
            managers_list.append(GamiResource(manager_resource_name, raw_manager[manager_collection_key]))

        return managers_list

    def _get_uuids_from_resource_list(self, resource_list):
        uuids_list = []
        for gami_resource in resource_list:
            uuids_list.append(gami_resource.get_uuid())

        return uuids_list

    def _search_resource_tree(self, resource_name, tree_root):
        """Recursively search GAMI data model for resources with a given name.
        Keyword arguments:
        resource_name -- name of reasource to be found
        tree_root -- GamiResource object to start the search
        """
        resources_list = []

        if tree_root.get_name() != resource_name:
            # get the list of all collections of a given resource
            collection_names = self._get_resource_collection_names(tree_root)
            component_uuid = tree_root.get_uuid()
            # get the list of all resources in a collection
            for collection_name in collection_names:
                collection_resource_name = self.gami_data_manager.find_resource_info(key="collection_name", value=collection_name)
                raw_resources = self._execute_command("getCollection", component=component_uuid, name=collection_name)
                for raw_resource in raw_resources:
                    resource = GamiResource(collection_resource_name, raw_resource["subcomponent"])
                    resources_list += self._search_resource_tree(resource_name, resource)
        else:
            resources_list = [tree_root]

        return resources_list

    def _get_resource_collection_names(self, resource):
        resource_name = resource.get_name()
        resource_uuid = resource.get_uuid()

        get_info_command_name = self.gami_data_manager.get_info_command_name(resource_name)
        component_name = self.gami_data_manager.get_info_command_component_name(resource_name)

        component_info = self._execute_command(get_info_command_name, **{component_name: resource_uuid})
        try:
            collection_names = [collection_entry["name"] for collection_entry in component_info["collections"]]
        except KeyError:
            collection_names = []

        return collection_names

    def _execute_command(self, command_name, **kwargs):
        function_from_command_name = getattr(self.json_server, command_name)
        return function_from_command_name(**kwargs)
