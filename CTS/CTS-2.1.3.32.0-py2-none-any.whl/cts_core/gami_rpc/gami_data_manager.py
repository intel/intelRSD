"""
 * @section LICENSE
 *
 * @copyright
 * Copyright (c) 2016 Intel Corporation
 *
 * @copyright
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * @copyright
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * @copyright
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @section DESCRIPTION
"""


class GamiResourceData:
    def __init__(self, command_name, component_name, collection_name):
        self.command_name = command_name
        self.component_name = component_name
        self.collection_name = collection_name

    def get_command_name(self):
        return self.command_name

    def get_component_name(self):
        return self.component_name

    def get_collection_name(self):
        return self.collection_name


class GamiDataManager:
    class Constants:
        MANAGER = 'Manager'
        GET_MANAGER_COLLECTION = 'getManagerCollection'
        MANAGER_COLLECTION_KEY = 'manager'

    _RESOURCE_NAME_TO_GAMI_RESOURCE_DATA = {
        'Manager': GamiResourceData(command_name='getManagerInfo', component_name='manager', collection_name='Managers'),
        'Chassis': GamiResourceData(command_name='getChassisInfo', component_name='chassis', collection_name='Chassis'),
        'System': GamiResourceData(command_name='getComputerSystemInfo', component_name='system', collection_name='Systems'),
        'Processor': GamiResourceData(command_name='getProcessorInfo', component_name='processor', collection_name='Processors'),
        'MemoryChunk': GamiResourceData(command_name='getMemoryChunkInfo', component_name='chunk',
                                        collection_name='MemoryChunks'),
        'Dimm': GamiResourceData(command_name='getDimmInfo', component_name='dimm', collection_name='Memories'),
        'NetworkInterface': GamiResourceData(command_name='getNetworkInterfaceInfo', component_name='interface',
                                             collection_name='NetworkInterfaces'),
        'StorageController': GamiResourceData(command_name='getStorageControllerInfo', component_name='controller',
                                              collection_name='StorageControllers'),
        'Drive': GamiResourceData(command_name='getDriveInfo', component_name='drive', collection_name='Drives'),
        'PortVlan': GamiResourceData(command_name='getPortVlanInfo', component_name='portVlan', collection_name='PortVlans'),
        'EthernetSwitch': GamiResourceData(command_name='getEthernetSwitchInfo', component_name='switch',
                                           collection_name='EthernetSwitches'),
        'EthernetSwitchPort': GamiResourceData(command_name='getEthernetSwitchPortInfo', component_name='port',
                                               collection_name='Ports'),
        'EthernetSwitchPortMember': GamiResourceData(command_name='getEthernetSwitchPortInfo', component_name='port',
                                                     collection_name='PortMembers'),
        'NeighborSwitch': GamiResourceData(command_name='getRemoteEthernetSwitchInfo', component_name='switch',
                                           collection_name='NeighborSwitches'),
        'Vlan': GamiResourceData(command_name='getVlanInfo', component_name='vlan', collection_name='Vlans'),
        'PowerZone': GamiResourceData(command_name='getPowerZoneInfo', component_name='zone', collection_name='PowerZones'),
        'Psu': GamiResourceData(command_name='getPsuInfo', component_name='psu', collection_name='Psus'),
        'ThermalZone': GamiResourceData(command_name='getThermalZoneInfo', component_name='zone', collection_name='ThermalZones'),
        'Fan': GamiResourceData(command_name='getFanInfo', component_name='fan', collection_name='Fans'),
        'AuthorizationCertificate': GamiResourceData(command_name='getAuthorizationCertificate', component_name='certificate',
                                                     collection_name='certificates'),
        'StorageServices': GamiResourceData(command_name='getStorageServicesInfo', component_name='services',
                                            collection_name='StorageServices'),
        'PhysicalDrive': GamiResourceData(command_name='getPhysicalDriveInfo', component_name='drive',
                                          collection_name='PhysicalDrives'),
        'LogicalDrive': GamiResourceData(command_name='getLogicalDriveInfo', component_name='drive',
                                         collection_name='LogicalDrives'),
        'IscsiTarget': GamiResourceData(command_name='getiSCSITargetInfo', component_name='target',
                                        collection_name='iSCSITargets'),
    }

    def get_collection_name(self, resource_name):
        gami_resource_data = self._RESOURCE_NAME_TO_GAMI_RESOURCE_DATA[resource_name]
        return gami_resource_data.get_collection_name()

    def get_info_command_name(self, resource_name):
        gami_resource_data = self._RESOURCE_NAME_TO_GAMI_RESOURCE_DATA[resource_name]
        return gami_resource_data.get_command_name()

    def get_info_command_component_name(self, resource_name):
        gami_resource_data = self._RESOURCE_NAME_TO_GAMI_RESOURCE_DATA[resource_name]
        return gami_resource_data.get_component_name()

    def find_resource_info(self, key=None, value=None):
        predicate_function = getattr(self, "get_" + key)
        for resource_name in self._RESOURCE_NAME_TO_GAMI_RESOURCE_DATA:
            if value == predicate_function(resource_name):
                return resource_name
        else:
            raise KeyError('Resource property %s with value %s not recognized' % (key, value))
