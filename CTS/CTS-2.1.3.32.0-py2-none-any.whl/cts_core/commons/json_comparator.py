"""
 * @section LICENSE
 *
 * @copyright
 * Copyright (c) 2016 Intel Corporation
 *
 * @copyright
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * @copyright
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * @copyright
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @section DESCRIPTION
"""


class JsonComparator:
    def __init__(self):
        pass

    @staticmethod
    def compare_json_to_golden(json, golden, ignore = []):
        """
        Recursively compares two jsons while ignoring the fields present in ignore list and the ones not present in golden.
        :param json: json to validate
        :param golden: the golden json (its fields have to match the given json's or be present in ignore list)
        :param ignore: list() of parameters to ignore (them not matching will not generate errors), if the element is nested,
        the convention is: "/dict1/dict2/.../parameter"
        :return: comparison status
        :rtype: bool
        """
        def compare_recursively(prefix, golden, json):
            status = True
            if type(golden) == dict:
                if type(json) != dict:
                    print "ERROR::%s should be a dict" % (prefix)
                    status = False
                else:
                    for key in golden.keys():
                        if "{}/{}".format(prefix, key) in ignore:
                            continue
                        if json and key in json:
                            if not compare_recursively(prefix = "{}/{}".format(prefix, key), golden=golden[key], json=json[key]):
                                status = False
                        else:
                            print "ERROR::Key %s not present in the compared json" % (key)
                            status = False
            elif type(golden) == list:
                if type(json) != list:
                    print "ERROR::%s should be a list" % (prefix)
                    status = False
                else:
                    for golden_key in golden:
                        key_found = False
                        for key in json:
                            if compare_recursively('', golden_key, key):
                                key_found = True
                                break
                        if not key_found:
                            print "ERROR::%s list element %s not found in the other json" % (prefix, golden_key)
                            status = False
                            break
            elif not JsonComparator.compare_jsons(golden, json):
                status = False

            return status

        return compare_recursively('', golden, json)

    @staticmethod
    def compare_jsons(json_a, json_b):
        """
        :return: comparison status
        :rtype: bool
        """
        if type(json_a) != type(json_b):
            # considering string is the same as unicode for jsons
            if not (isinstance(json_a, basestring) and isinstance(json_b, basestring)):
                print "ERROR::Mismatch between %s (%s) and %s (%s) types" % (json_a, type(json_a), json_b, type(json_b ))
                return False

        try:
            compare_func = {dict: JsonComparator.compare_dicts, list: JsonComparator.compare_lists}[type(json_a)]
        except KeyError:
            compare_func = JsonComparator.compare_variables

        return compare_func(json_a, json_b)

    @staticmethod
    def compare_lists(list_a, list_b):
        """
        :type list_a: list[]
        :type list_b: list[]
        :rtype: bool
        """
        status = True
        if len(list_a) != len(list_b):
            print "ERROR::lists %s and %s have different length" % (list_a, list_b)
            return False

        list_a = sorted(list_a)
        list_b = sorted(list_b)
        for it in range(len(list_a)):
            if not JsonComparator.compare_jsons(list_a[it], list_b[it]):
                status = False

        return status

    @staticmethod
    def compare_dicts(dict_a, dict_b):
        """
        :dict dictA: dict[]
        :dict dictB: dict[]
        :rtype: bool
        """
        if len(dict_a.keys()) != len(dict_b.keys()):
            print "ERROR::Dictionaries %s and %s have different keys numbers" % (dict_a, dict_b)
            return False
        status = True

        for key in dict_a.keys():
            try:
                if not JsonComparator.compare_jsons(dict_a[key], dict_b[key]):
                    status = False
            except KeyError:
                print "ERROR::Key %s present in dictionary %s but not present in dictionary %s" % (key, dict_a, dict_b)
                status = False

        return status

    @staticmethod
    def compare_variables(var_a, var_b):
        """
        :rtype: bool
        """
        float_epsilon = 1e-8

        if type(var_a) == float and abs(var_a - var_b) < float_epsilon:
            var_a = var_b

        if var_a != var_b:
            print "ERROR::Mismatch of values %s and %s" % (var_a, var_b)
        return var_a == var_b
