from cts_core.validation.validation_status import ValidationStatus


class Requirement:
    def __init__(self, base, min = None, max = None):
        self.base = base
        self.min = min
        self.max = max


class Preconditions:
    def __init__(self, metadata_container, requirements):
        """
        :type metadata_container: cts_core.metadata.metadata_container.MetadataContainer
        :type requirements: list(Requirement)
        """
        self._metadata_container = metadata_container
        self.requirements = requirements

    def validate(self, discovery_container):
        """
        :type discovery_container: cts_core.discovery.discovery_container.DiscoveryContainer
        :rtype: cts_core.validation.validation_status.ValidationStatus
        """
        return self._precondition_check(discovery_container)

    def _precondition_check(self, discovery_container):
        """
        :type discovery_container: cts_core.discovery.discovery_container.DiscoveryContainer
        :rtype: cts_core.validation.validation_status.ValidationStatus
        """
        status = ValidationStatus.PASSED

        if self.requirements is None:
            return status

        for requirement in self.requirements:
            if requirement.base not in self._metadata_container.entities:
                print "ERROR::Internal Error. Type %s not found in metadata" % requirement.base
                status = ValidationStatus.FAILED

        discovered = dict()

        for resource_link, resource in discovery_container.iteritems():
            for requirement in self.requirements:
                try:
                    if self._metadata_container.entities[requirement.base].compare_entities(resource.odata_type):
                        discovered[requirement.base] = discovered.setdefault(requirement.base, 0) + 1
                except KeyError as error:
                    print "WARNING::Unable to check precondition. %s not found in metadata" % requirement.base
                    status = ValidationStatus.FAILED

        for requirement in self.requirements:
            if (requirement.min is not None and discovered.setdefault(requirement.base, 0) < requirement.min):
                print "ERROR::Minimum number of %s is %d. Current number: %d" % \
                      (requirement.base, requirement.min, discovered[requirement.base])
                status = ValidationStatus.FAILED
            if (requirement.max is not None and discovered.setdefault(requirement.base, 0) > requirement.max):
                print "ERROR::Maximum number of %s is %d. Current number: %d" % \
                      (requirement.base, requirement.max, discovered[requirement.base])
                status = ValidationStatus.FAILED

        return status