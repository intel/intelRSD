"""
 * @section LICENSE
 *
 * @copyright
 * Copyright (c) 2016 Intel Corporation
 *
 * @copyright
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * @copyright
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * @copyright
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @section DESCRIPTION
"""

import json
import pickle
import time
from distutils.util import strtobool
from os import getppid
from traceback import format_exc

import requests
from simplejson.scanner import JSONDecodeError

from cts_core.commons.links_factory import LinksFactory
from cts_framework.commons.enums import RequestStatus, ReturnCodes, HttpMethods
from cts_framework.configuration.config_property_reader import ValueNotFound
from cts_framework.db.dao.http_request_dao import HttpRequestDAO
from cts_framework.db.dao.script_dao import ScriptDAO

TASK_TIMEOUT = 200

class AsyncOperation(Exception):
    pass


class ApiCaller:
    def __init__(self, config_property_reader):
        self._links_factory = LinksFactory(config_property_reader.ApiEndpoint)
        self._config_property_reader = config_property_reader
        try:
            self.script_execution_id = ScriptDAO.get_last_script_execution_id()
            if self.script_execution_id != None:
                script_execution = ScriptDAO.get_script_execution_details(self.script_execution_id)
                if getppid() != script_execution.pid:
                    # this is probably replay or running test script without framework
                    # do not register requests
                    self.script_execution_id = None
        except:
            self.script_execution_id = None

        self.request_registration = self.script_execution_id is not None

        try:
            if strtobool(self._config_property_reader.UseSSL):
                self.ssl = True
            else:
                self.ssl = False
        except ValueNotFound:
            self.ssl = False

    def _perform_call(self, odata_id, http_method=None, acceptable_return_codes=None, payload=None):
        if not http_method:
            http_method = HttpMethods.GET

        if not acceptable_return_codes:
            return_codes_for_methods = {HttpMethods.PATCH: [ReturnCodes.NO_CONTENT, ReturnCodes.ACCEPTED, ReturnCodes.OK],
                                        HttpMethods.POST: [ReturnCodes.CREATED, ReturnCodes.ACCEPTED],
                                        HttpMethods.DELETE: [ReturnCodes.NO_CONTENT, ReturnCodes.ACCEPTED],
                                        HttpMethods.GET: [ReturnCodes.OK]}
            acceptable_return_codes = return_codes_for_methods[http_method]

        url, kwargs = self.build_request_params(odata_id, payload)

        print "MESSAGE::-%s %s" % (http_method, url)
        if not self.request_registration:
            self.log_request(kwargs)

        requests_method = {HttpMethods.GET: requests.get, HttpMethods.PATCH: requests.patch,
                           HttpMethods.POST: requests.post, HttpMethods.DELETE: requests.delete}[http_method]

        try:
            try:
                # Try to suppress user warnings
                from requests.packages.urllib3.exceptions import InsecureRequestWarning
                from requests.packages.urllib3 import disable_warnings
                disable_warnings(InsecureRequestWarning)
            except:
                pass
            try:
                # Try to suppress user warnings
                from urllib3.exceptions import InsecureRequestWarning
                from urllib3 import disable_warnings
                disable_warnings(InsecureRequestWarning)
            except:
                pass


            response = requests_method(url, **kwargs)

            #register request/response in databasenn
            if self.request_registration:
                request_id = HttpRequestDAO.register_request(self.script_execution_id, http_method, url,
                                                             json.dumps(kwargs), pickle.dumps(response),
                                                             response.status_code)
                print "METADATA::request_id=%d" % request_id


            status = RequestStatus.SUCCESS if response.status_code in acceptable_return_codes else RequestStatus.FAILED
            status_code, headers = response.status_code, response.headers

            if response.status_code in [ReturnCodes.NO_CONTENT, ReturnCodes.CREATED]:
                response_body = dict()
            else:
                response_body = response.json()

            if not self.request_registration:
                self.log_response(response, response_body)

        except requests.RequestException as err:
            print "ERROR:: Error '%s' occurred when accessing resource %s" % (err.message, odata_id)
            return RequestStatus.FAILED, None, None, None
        except JSONDecodeError as err:
            print "ERROR::Unable to parse resource %s to json due to error '%s'" % (odata_id, err.message)
            return RequestStatus.FAILED, None, None, None
        except Exception as err:
            print "ERROR::Unknown exception '%s' while accessing resource %s : %s" % (err.message, odata_id, format_exc().replace('\n', '\nERROR::'))
            return RequestStatus.FAILED, None, None, None

        return status, status_code, response_body, headers

    def log_request(self, kwargs):
        print "MESSAGE:: request parameters {"
        for key, value in kwargs.iteritems():
            print "MESSAGE::     %s:%s" % (str(key), str(value))
        print "MESSAGE:: }"

    def log_response(self, response, response_body):
        pretty_response = json.dumps(response_body, indent=4) \
            if response.status_code != ReturnCodes.NO_CONTENT else "No content"
        print "MESSAGE::status code: %d" % response.status_code
        print "MESSAGE::response:"
        for r in pretty_response.split('\n'):
            print "MESSAGE::%s\n" % (r)

    def get_resource(self, odata_id, acceptable_return_codes=None):
        """
        Sends http GET request to remote endpoint and retrieves resource odata_id.

        :type odata_id: str
        :type acceptable_return_codes: list(int)
        """
        status, status_code, response_body, headers = self._perform_call(odata_id, acceptable_return_codes=acceptable_return_codes)

        return status, status_code, response_body, headers


    def post_resource(self, odata_id, payload=None, acceptable_return_codes=None, wait_if_async=True):
        """
        Sends http POST request to remote endpoint.
        Throws AsyncOperation if service created task in response to this request.

        :type odata_id: str
        :type payload: dict
        :type acceptable_return_codes: list(int)
        :type wait_if_async: bool
        """

        status, status_code, response_body, headers = self._perform_call(odata_id,
                                                                         http_method=HttpMethods.POST,
                                                                         payload=payload,
                                                                         acceptable_return_codes=acceptable_return_codes)
        # determine if the operation was completed synchronously or asynchronously
        if status_code == ReturnCodes.ACCEPTED:
            if not wait_if_async:
                raise AsyncOperation()
            status, status_code, response_body, headers = self._wait_for_task(headers)


        return status, status_code, response_body, headers

    def patch_resource(self, odata_id, payload=None, acceptable_return_codes=None, wait_if_async=True):
        """
        Sends http PATCH request to remote endpoint.
        Throws AsyncOperation if service created task in response to this request.

        :type odata_id: str
        :type payload: dict
        :type acceptable_return_codes: list(int)
        :type wait_if_async: bool
        """

        status, status_code, response_body, headers = self._perform_call(odata_id,
                                                                         http_method=HttpMethods.PATCH,
                                                                         payload=payload,
                                                                         acceptable_return_codes=acceptable_return_codes)
        # determine if the operation was completed synchronously or asynchronously
        if status_code == ReturnCodes.ACCEPTED:
            if not wait_if_async:
                raise AsyncOperation()
            status, status_code, response_body, headers = self._wait_for_task(headers)

        return status, status_code, response_body, headers

    def delete_resource(self, odata_id, acceptable_return_codes=None, wait_if_async=True):
        """
        Sends http DELETE request to remote endpoint.
        Throws AsyncOperation if service created task in response to this request.

        :type odata_id: str
        :type acceptable_return_codes: list(int)
        :type wait_if_async: bool
        """
        status, status_code, response_body, headers = self._perform_call(odata_id,
                                                                         http_method=HttpMethods.DELETE,
                                                                         acceptable_return_codes=acceptable_return_codes)

        #determine if the operation was completed synchronously or asynchronously
        if status_code == ReturnCodes.ACCEPTED:
            if not wait_if_async:
                raise AsyncOperation()
            status, status_code, response_body, headers = self._wait_for_task(headers)

        return status, status_code, response_body, headers

    def _wait_for_task(self, headers):
        task_monitor = headers.get('Location')
        print "MESSAGE::Waiting for task completion. Monitor = %s" % task_monitor
        if task_monitor:
            for i in range(0, TASK_TIMEOUT):
                status, status_code, task, headers = self.get_resource(task_monitor,
                                                                       [ReturnCodes.OK, ReturnCodes.CREATED])

                # The client may also cancel the operation by performing a DELETE on the Task resource. Deleting the
                # Task resource object may invalidate the associated Task Monitor and subsequent GET on the Task
                # Monitor URL returns either 410 (Gone) or 404 (Not Found)
                if status_code in [ReturnCodes.NOT_FOUND, ReturnCodes.GONE]:
                    print "WARNING::Task was cancelled unexpectedly"
                    return RequestStatus.FAILED, None, None, None

                # Once the operation has completed, the Task Monitor shall return a status code of OK (200) or
                # CREATED (201) for POST and include the headers and response body of the initial operation, as if it
                #  had completed synchronously
                if status_code in [ReturnCodes.OK, ReturnCodes.CREATED]:
                    return status, status_code, task, headers

                # As long as the operation is in process, the service shall continue to return a status code of
                # 202 (Accepted) when querying the Task Monitor returned in the location header
                if status_code not in [ReturnCodes.ACCEPTED]:
                    print "ERROR::Task monitor returned unexpected status code: %d" % status_code
                    return RequestStatus.FAILED, None, None, None

                print "MESSAGE::Task in progress. Waiting for completion"
                time.sleep(1)
        else:
            print "ERROR::Task has been created but Location header not found"
            return RequestStatus.FAILED, None, None, None

    def build_request_params(self, odata_id, payload=None):
        link = self._links_factory.get_resource_link(odata_id, ssl=self.ssl)

        kwargs = dict(verify=False, headers={"Content-Type": "application/json", "Accept": "application/json"})
        try:
            kwargs["cert"] = (self._config_property_reader.CertificateCertFile,
                              self._config_property_reader.CertificateKeyFile)
        except ValueNotFound:
            # not using certificate authorization
            pass
        try:
            kwargs["auth"] = (self._config_property_reader.User, self._config_property_reader.Password)
        except ValueNotFound:
            pass

        if payload:
            kwargs["data"] = json.dumps(payload)

        return link, kwargs

    def read_certificate(self, certificate_file):
        try:
            with open(certificate_file, "r") as f:
                return f.read()
        except IOError:
            pass

        return None
