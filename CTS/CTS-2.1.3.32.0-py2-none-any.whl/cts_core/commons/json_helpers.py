"""
 * @section LICENSE
 *
 * @copyright
 * Copyright (c) 2016 Intel Corporation
 *
 * @copyright
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * @copyright
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * @copyright
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @section DESCRIPTION
"""

def get_odata_type(obj):
    """
    Retrieves odata.type from given object. May throw KeyError.
    :param obj: object that potentially contains '@odata.type" property
    :return:
    """
    if not isinstance(obj, dict):
        raise KeyError
    type = obj["@odata.type"]
    return sanitize_odata_type(type)


def is_special_property(property_name):
    return "#" in property_name or "@" in property_name

def sanitize_odata_type(odata_type):
    if odata_type and odata_type.startswith('#'):
        return odata_type[1:]
    return odata_type
