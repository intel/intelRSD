"""
 * @section LICENSE
 *
 * @copyright
 * Copyright (c) 2016 Intel Corporation
 *
 * @copyright
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * @copyright
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * @copyright
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @section DESCRIPTION
"""

from bs4 import BeautifulSoup
from traceback import format_exc
from cts_core.commons.api_caller import ApiCaller
from cts_core.commons.json_helpers import get_odata_type
from cts_core.commons.preconditions import Preconditions
from cts_core.discovery.api_resource import ApiResource
from cts_core.metadata.model.metadata_types.metadata_type_categories import MetadataTypeCategories
from cts_core.metadata.model.property import PatchStatus, Property
from cts_core.validation.validation_status import ValidationStatus
from cts_framework.commons.enums import RequestStatus

class MetadataPatchValidator:
    def __init__(self, metadata_container, configuration, strategy, requirements = None):
        """
        :type metadata_container: cts_core.metadata.metadata_container.MetadataContainer
        :type strategy: cts_core.validation.patch.patching_strategy.PatchingStrategy
        """
        self._metadata_container = metadata_container
        self._api_caller = ApiCaller(configuration)
        self._strategy = strategy
        self._preconditions = Preconditions(metadata_container, requirements)

    def validate(self, discovery_container):
        print "TEST_CASE::Checking for mandatory entities"
        status = self._preconditions.validate(discovery_container)
        print "STATUS::%s" % status

        resources = discovery_container.values()
        count = len(resources)
        for idx, api_resource in enumerate(resources):
            print "SCREEN::" + "-" * 80
            progress = "[%5d/%5d]" % (idx + 1, count)
            print "MESSAGE::%s" % progress
            print "MESSAGE::Checking %s : %s" \
                  % (api_resource.odata_id, api_resource.odata_type)

            attempted_patches = []
            resource_status = self._validate_resource(api_resource, attempted_patches)
            if not attempted_patches:
                if resource_status not in [ValidationStatus.PASSED, ValidationStatus.PASSED_WITH_WARNINGS]:
                    # 0 attempted patches means 0 test cases.
                    # FAILED means error (visible in the log) happened during validation, but not associated with any TEST_CASE
                    # For the purpose of showing failing test case, we produce dummy TEST_CASE here
                    print "TEST_CASE::Patching %s" % api_resource.odata_id
                    print "STATUS::%s" % resource_status
                else:
                    print "MESSAGE::[{resource} - 0 patchable properties found]".format(resource=api_resource.odata_id)
            status = ValidationStatus.join_statuses(status, resource_status)

        print "SCREEN::Overall status: %s" % status
        return status

    def _validate_resource(self, api_resource, attempted_patches):
        """
        :type api_resource: cts_core.discovery.api_resource.ApiResource
        :rtype: str
        """
        if self._metadata_container.to_be_ignored(api_resource.odata_type):
            return ValidationStatus.PASSED

        try:
            properties_list = self._metadata_container.entities[api_resource.odata_type].properties.values()
            try:
                return self._validate_property_list(api_resource, list(), properties_list, attempted_patches)
            except:
                print "ERROR::Unhandled exception {exception} while handling resource {odata_id}".format(
                    exception=format_exc().replace('\n', '\nERROR::'), odata_id=api_resource.odata_id)
                return ValidationStatus.FAILED
        except KeyError:
            print "ERROR:: Unable to find definition of entity %s" % api_resource.odata_type
            return ValidationStatus.FAILED

    def _validate_property_list(self, api_resource, variable_path, properties_list, attempted_patches):
        """
        :type api_resource: cts_core.discovery.api_resource.ApiResource
        :type variable_path: list [str or int]
        :type properties_list: list[cts_core.metadata.model.property.Property]
        :rtype: str
        """
        status = ValidationStatus.PASSED
        for property_description in properties_list:
            status = ValidationStatus.join_statuses(self._validate_property(api_resource, variable_path,
                                                                            property_description,
                                                                            attempted_patches),
                                                    status)

        #validate additional properties
        try:
            body = api_resource.get_value_from_path(variable_path)
        except KeyError as key:
            print "WARNING::Unable to access %s->%s. Key=%s" % (api_resource.odata_id, "->".join(variable_path), key)
            body = None

        if body is not None:
            all_properties = set(body.keys())
            known_properties = set([property.name for property in properties_list])
            additional_properties = all_properties - known_properties
            for additional_property_name in additional_properties:
                property_value = body[additional_property_name]
                if isinstance(property_value, dict) and "@odata.type" in property_value:
                    raw_soup = """
                    <Property Name = "{name}" Type="{type}">
                        <Annotation Term="OData.Permissions" EnumMember = "OData.Permissions/ReadWrite"/>
                    </Property>
                    """
                    soup = BeautifulSoup(raw_soup.format(name=additional_property_name, type=get_odata_type(property_value)),
                                         "lxml").find_all("property")[0]

                    adhoc_description = Property(self._metadata_container, None, soup)
                    status = ValidationStatus.join_statuses(self._validate_property(api_resource,
                                                                                    variable_path,
                                                                                    adhoc_description,
                                                                                    attempted_patches),
                                                            status)


        return status

    def _validate_property(self, api_resource, variable_path, property_description, attempted_patches, skip_collection=False):
        """
        :type api_resource: cts_core.discovery.api_resource.ApiResource
        :type variable_path: list [str or int]
        :type property_description: cts_core.metadata.model.property.Property
        :type skip_collection: bool
        :rtype: str
        """

        if not skip_collection:
            variable_path = variable_path + [property_description.name]

        try:
            property_body = api_resource.get_value_from_path(variable_path)
        except KeyError as error:
            if property_description.is_required:
                print "TEST_CASE::Patching %s->%s" % (api_resource.odata_id, "->".join(variable_path))
                print "ERROR::Unable to patch %s" % error
                status = ValidationStatus.FAILED
                print "STATUS::%s" % status
            else:
                status = ValidationStatus.PASSED

            return status

        if property_description.is_collection and not skip_collection:
            status = ValidationStatus.PASSED

            for path_element, _ in enumerate(property_body):
                status = ValidationStatus.join_statuses(status, self._validate_property(api_resource,
                                                                                         variable_path + [path_element],
                                                                                        property_description,
                                                                                        attempted_patches,
                                                                                        skip_collection=True))

            return status
        else:
            try:
                if self._metadata_container.types[property_description.type].type_category == MetadataTypeCategories.COMPLEX_TYPE:
                    return self._validate_property_list(api_resource, variable_path,
                                                        self._metadata_container.types[property_description.type].properties.values(),
                                                        attempted_patches)
                else:
                    return self._validate_leaf_property(api_resource, variable_path, property_description, attempted_patches)
            except KeyError as key:
                print "ERROR:: Unable to find definition of type %s referenced in %s" % (key, api_resource.odata_id)
                return ValidationStatus.FAILED

    def _validate_leaf_property(self, api_resource, variable_path, property_description, attempted_patches):
        """
        :type api_resource: cts_core.discovery.api_resource.ApiResource
        :type variable_path: list [str or int]
        :type property_description: cts_core.metadata.model.property.Property
        :rtype: str
        """
        if property_description.patch_status == PatchStatus.PATCHABLE:
            return self._validate_patchable_property(api_resource, variable_path, property_description,
                                                     attempted_patches)
        else:
            return ValidationStatus.PASSED

    def _validate_patchable_property(self, api_resource, variable_path, property_description, attempted_patches):
        """
        :type api_resource: cts_core.discovery.api_resource.ApiResource
        :type variable_path: list [str or int]
        :type property_description: cts_core.metadata.model.property.Property
        :rtype: str
        """
        new_values_list = property_description.generate_values(property_description.annotations)

        total_status = ValidationStatus.PASSED

        allowable = api_resource.get_allowable_from_path(variable_path)
        if allowable:
            new_values_list = [value for value in new_values_list if value in allowable]

        for new_value in new_values_list:
            total_status = ValidationStatus.join_statuses(
                self._validate_single_value_patchable_property(api_resource,
                                                               variable_path,
                                                               property_description,
                                                               new_value,
                                                               attempted_patches),
                total_status)

        return total_status

    def _validate_single_value_patchable_property(self, api_resource, variable_path, property_description,
                                                  value_requested, attempted_patches):
        """
        :type api_resource: cts_core.discovery.api_resource.ApiResource
        :type variable_path: list [str or int]
        :type property_description: cts_core.metadata.model.property.Property
        :type value_requested: *
        :rtype: str
        """
        overall_property_status = ValidationStatus.PASSED
        property = "%s[%s]" % (api_resource.odata_id, "->".join([str(path) for path in variable_path]))

        try:
            value_pre = api_resource.get_value_from_path(variable_path)
        except KeyError:
            return ValidationStatus.PASSED

        print "TEST_CASE:: Patch %s.%s := %s" % (api_resource.odata_id, property, str(value_requested))
        attempted_patches.append("%s=%s" % (property, str(value_requested)))

        data = self.create_data(variable_path, value_requested)

        status, status_code, response_body, headers = self._api_caller.patch_resource(
            api_resource.odata_id, payload=data,
            acceptable_return_codes=self._strategy.allowable_return_codes)

        patch_applied = self._strategy.was_patch_applied(status_code)
        if status != RequestStatus.SUCCESS:
            print "WARNING::Patching %s from %s to %s failed (unexpected status code: %s)" % \
                  (property, value_pre, value_requested, str(status_code))
            validation_status = ValidationStatus.PASSED_WITH_WARNINGS
        elif not patch_applied:
            print "WARNING::Patching %s from %s to %s failed (patch not applied)" % \
                  (property, value_pre, value_requested)
            validation_status = ValidationStatus.PASSED_WITH_WARNINGS
        else:
            validation_status = ValidationStatus.PASSED

        overall_property_status = ValidationStatus.join_statuses(overall_property_status,
                                                                 validation_status)
        print "STATUS::%s" % validation_status


        # only verify if the PATCH request succeeded
        if status == RequestStatus.SUCCESS and patch_applied:
            print "TEST_CASE::Verify %s.%s (expected: %s)" % (api_resource.odata_id, property, str(value_requested))
            validation_status = ValidationStatus.PASSED

            status, status_code, response_body, headers = self._api_caller.get_resource(api_resource.odata_id)

            if status == RequestStatus.SUCCESS:
                try:
                    value_post = ApiResource(response_body, api_resource.odata_type).get_value_from_path(variable_path)
                except KeyError:
                    print "WARNING::After patch verification not possible. Property %s not found" % (property)
                    validation_status = ValidationStatus.PASSED_WITH_WARNINGS

                if value_requested != value_post and patch_applied:
                    print "WARNING::Patching %s failed - IS : [%s], EXPECTED :[%s]\n" \
                          % (property, str(value_post), str(value_requested))
                    validation_status = ValidationStatus.PASSED_WITH_WARNINGS
                elif value_pre != value_post and not patch_applied:
                    print "WARNING::Patch not applied but %s has changed from [%s] to [%s]\n" \
                          % (property, str(value_pre), str(value_post))
                    validation_status = ValidationStatus.PASSED_WITH_WARNINGS
            else:
                print "WARNING::GET %s failed (unexpected status code: %s)" % \
                      (property, str(status_code))
                validation_status = ValidationStatus.PASSED_WITH_WARNINGS

            overall_property_status = ValidationStatus.join_statuses(overall_property_status,
                                                                     validation_status)
            print "STATUS::%s" % validation_status
        else:
            print "MESSAGE::Patch not applied, skipping the verifying test case"


        print "TEST_CASE::Restore %s.%s := %s" % (api_resource.odata_id, property, str(value_pre))
        data = self.create_data(variable_path, value_pre)
        status, status_code, response_body, headers = self._api_caller.patch_resource(
            api_resource.odata_id, payload=data,
            acceptable_return_codes=self._strategy.allowable_return_codes)

        if status != RequestStatus.SUCCESS:
            print "WARNING::Restoring %s failed. status code %s" % (property, status_code)
            # change FAIL to WARNING
            validation_status = ValidationStatus.PASSED_WITH_WARNINGS

        overall_property_status = ValidationStatus.join_statuses(overall_property_status,
                                                                 validation_status)
        print "STATUS::%s" % validation_status


        return overall_property_status


    @staticmethod
    def create_data(variable_path, value):
        """
        :type variable_path: list [int or str]
        :type value: *
        :rtype: dict
        """
        data = value
        for path_element in variable_path[::-1]:
            if type(path_element) == int:
                data = ([dict()] * path_element) + [data]
            else:
                data = {path_element: data}

        return data
