from cts_core.validation.validation_status import ValidationStatus
from cts_core.discovery.discovery_container import DiscoveryContainer
from cts_core.discovery.api_resource import ApiResource

class HierarchyValidator:
    def __init__(self, discovery_container, metadata_container, metadata_constants):
        """
        :type discovery_container: DiscoveryContainer
        """
        self.discover_container = discovery_container
        self.metadata_container = metadata_container
        self.metadata_constants = metadata_constants

    def validate_path_using_contains_property(self):
        res = ValidationStatus.PASSED
        remained_to_be_visited = [r.odata_id for r in self.discover_container.physical_location_aware_resources()]
        root_resources = self.discover_container.root_resources()
        if root_resources:
            if len(root_resources) > 1:
                root = ", ".join([r.odata_id for r in root_resources])
                print "ERROR::More than one root resource (with NULL ParentId). " \
                      "Expected only one. Root resources found: %s" % root
                res = ValidationStatus.FAILED

            for root in root_resources:
                res = ValidationStatus.join_statuses(
                    self._validate_from(root, remained_to_be_visited, parent_location=None, parent_odata_id=None),
                    res)

        else:
            if self.discover_container.physical_location_aware_resources():
                print "ERROR::Resources with Location in Oem property has been found, but none has NULL ParentId."
                res = ValidationStatus.FAILED

        if remained_to_be_visited:
            print "ERROR::Not all location-aware resources visited while traversing tree using 'Link->Contains'. "\
            "Unreachable are: %s" % remained_to_be_visited
            res = ValidationStatus.FAILED

        return res

    def _validate_from(self, resource, remained_to_be_visited, parent_location=None, parent_odata_id=None):
        """
        :type resource: ApiResource
        :rtype: str
        """
        res = ValidationStatus.PASSED

        if resource.odata_id in remained_to_be_visited:
            remained_to_be_visited.remove(resource.odata_id)

        location = resource.location

        if location and location.parent_id:
            if not parent_location:
                print "ERROR::Resource %s has no location specified, but child resource %s has Location->ParentId=%s" \
                      % (parent_odata_id, resource.odata_id, location.parent_id)
                res = ValidationStatus.FAILED

        if parent_location:
            if location.parent_id != parent_location.id:
                print "ERROR::Resource %s contains resource %s, but child resource has invalid Location->ParentId. Is: %s. Expected: %s" \
                      % (parent_odata_id, resource.odata_id, location.parent_id, parent_location.id)
                res = ValidationStatus.FAILED
        if parent_odata_id and resource.contained_by:
            if parent_odata_id != resource.contained_by:
                print "ERROR::Resource %s has ContainedBy=%s, but it's parent is %s" \
                       % (resource.odata_id, resource.contained_by, parent_odata_id)
                res = ValidationStatus.FAILED
        if res != ValidationStatus.FAILED and resource.contains:

            locations_within_scope = dict()

            for sub_resource_id in resource.contains:
                try:
                    sub_resource = self.discover_container[sub_resource_id]
                    # validate that resources have unique location id within scope of their parent
                    if sub_resource.location.id in locations_within_scope:
                        print "ERROR::Resource %s has location id %s that conflicts with resources: %s" \
                        % (sub_resource.odata_id, sub_resource.location.id, locations_within_scope[sub_resource.location.id])
                        res = ValidationStatus.FAILED
                    locations_within_scope.setdefault(sub_resource.location.id, []).append(sub_resource.odata_id)

                    res = ValidationStatus.join_statuses(res, self._validate_from(sub_resource, remained_to_be_visited,
                                                                                  location, resource.odata_id))
                except KeyError:
                    print "ERROR::Resource %s declares that contains resource %s, but %s not found" \
                    % (resource.odata_id, sub_resource_id, sub_resource_id)
                    res = ValidationStatus.FAILED

        return res

    def validate_all_or_none_chassis_have_location(self):
        """
        OEM may support Location RackScale extension. When it does, Location should be present in each Chassis resource
        """
        chassis_entities = [r for r in self.discover_container.iter_all(self.metadata_constants.CHASSIS, self.metadata_container)]
        chassis = [r.odata_id for r in chassis_entities]
        chassis_with_location = [r.odata_id for r in chassis_entities if r.location]
        num_chassis = len(chassis)
        num_resources_with_location = len(chassis_with_location)

        if num_chassis > 0:
            if num_resources_with_location == 0:
                print "ERROR::Oem/Intel_RackScale/Location not found in Chassis entities"
                return ValidationStatus.FAILED

            if num_chassis != num_resources_with_location:
                print "ERROR::Some chassis have Oem/Intel_RackScale/Location some does not. See: %s" % (set(chassis) - set(chassis_with_location))
                return ValidationStatus.FAILED

        return ValidationStatus.PASSED
