"""
 * @section LICENSE
 *
 * @copyright
 * Copyright (c) 2016 Intel Corporation
 *
 * @copyright
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * @copyright
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * @copyright
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @section DESCRIPTION
"""

class DiscoveryContainer(dict):
    def is_visited(self, odata_id):
        return odata_id in self.keys()

    def add_resource(self, odata_id, resource=None):
        """
        :type odata_id: str
        :type resource: cts_core.discovery.api_resource.ApiResource
        :return:
        """
        self[odata_id] = resource

    def remove_resource(self, odata_id):
        """
        :type odata_id: str
        :return:
        """
        del self[odata_id]

    def iter_all(self, odata_type, metadata_container):
        """
        :type odata_type: str

        returns generator of resources of given @odata.type
        """
        resources = (r for r in self.itervalues()
                     if odata_type in metadata_container.entities
                     and metadata_container.entities[odata_type].compare_entities(r.odata_type))
        return resources

    def physical_location_aware_resources(self):
        """
        :rtype: list[ApiResource]
        """
        resources = [r for _, r in self.iteritems() if r.location]
        return resources


    def root_resources(self):
        """
        :rtype: list[ApiResource]
        """
        resources = [r for r in self.physical_location_aware_resources() if not r.location.parent_id]
        return resources
