"""
 * @section LICENSE
 *
 * @copyright
 * Copyright (c) 2016 Intel Corporation
 *
 * @copyright
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * @copyright
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * @copyright
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @section DESCRIPTION
"""
import pickle
from os import environ, getenv
from bs4 import BeautifulSoup
from copy import copy
from jsonpointer import resolve_pointer, JsonPointerException

from cts_core.commons.api_caller import ApiCaller
from cts_core.commons.json_helpers import get_odata_type, is_special_property
from cts_core.discovery.api_resource import ApiResource
from cts_core.discovery.discovery_container import DiscoveryContainer
from cts_core.metadata.model.metadata_types.dynamic_properties import match_dynamic_property
from cts_core.metadata.model.metadata_types.metadata_type_categories import MetadataTypeCategories
from cts_core.metadata.model.property import Property
from cts_core.validation.validation_status import ValidationStatus
from cts_framework.commons.enums import RequestStatus

ODATA = "@odata"
TYPE = "type"
ID = "id"


class Path:
    def __init__(self):
        self.path = []

    def append(self, property):
        path = Path()
        path.path = copy(self.path)
        path.path.append(property)
        return path

    def __str__(self):
        return '.'.join(self.path)


class ApiExplorer:
    def __init__(self, metadata_container, config_property_reader):
        """
        :type metadata_container: cts_core.metadata.metadata_container.MetadataContainer
        :type config_property_reader:
        """
        self._metadata_container = metadata_container
        self._api_caller = ApiCaller(config_property_reader)
        self._config_property_reader = config_property_reader
        self._status = ValidationStatus.UNKNOWN
        self._discovery_container = None

    def discover(self, odata_id, expected_odata_type, discovery_container=None):
        """
        :type discovery_container: cts_core.discovery.discovery_container.DiscoveryContainer
        :rtype: (cts_core.discovery.discovery_container.DiscoveryContainer, cts_core.validation.validation_status.ValidationStatus)
        """
        self._status = ValidationStatus.PASSED

        if getenv('CTS_UNPICKLE', None):
            self._discovery_container = pickle.load(open(environ['CTS_UNPICKLE'], 'rb'))
            return self._discovery_container, self._status

        self._discovery_container = discovery_container if discovery_container is not None else DiscoveryContainer()
        self._explore_resource(odata_id, expected_odata_type)

        if getenv('CTS_PICKLE', None):
            pickle.dump(self._discovery_container, open(environ['CTS_PICKLE'], 'wb'))

        return self._discovery_container, self._status

    def _explore_resource(self, odata_id, expected_odata_type):
        """
        :type odata_id: str
        """
        if odata_id is None:
            return

        if self._discovery_container.is_visited(odata_id):
            return

        status, response_body = self._get_resource(odata_id)

        if not response_body:
            print "ERROR::Unable to retrieve resource %s. Empty resource received." % odata_id
            self._status = ValidationStatus.FAILED
            return

        if status == RequestStatus.SUCCESS and response_body:
            api_resource = ApiResource(response_body, expected_odata_type)
            self._discovery_container.add_resource(odata_id, api_resource)
            self._process_resource(api_resource, odata_id=odata_id)

    def _get_resource(self, odata_id):
        status, status_code, response_body, headers = self._api_caller.get_resource(odata_id)

        if status != RequestStatus.SUCCESS:
            print "ERROR::Error while executing GET %s" % odata_id
            self._status = ValidationStatus.FAILED

        return self._dereference_jsonpointer_if_any(odata_id, response_body)

    def _dereference_jsonpointer_if_any(self, odata_id, response_body):
        pointer_pos = odata_id.find("#")
        if pointer_pos != -1:
            pointer = odata_id[pointer_pos + 1:]
            if not pointer or pointer[0] != '/':
                pointer = '/' + pointer
            try:
                return RequestStatus.SUCCESS, resolve_pointer(response_body, pointer)
            except JsonPointerException as exception:
                print "ERROR::JSON pointer exception while dereferencing {path} from {odata_id} resource; Error: {error}" \
                    .format(path=pointer, odata_id=odata_id, error=exception)
                self._status = ValidationStatus.FAILED
                return RequestStatus.FAILED, {}
        return RequestStatus.SUCCESS, response_body

    def _process_resource(self, api_resource, odata_id):
        """
        :type api_resource: cts_core.discovery.api_resource.ApiResource
        """
        try:
            type_definition = self._metadata_container.entities[api_resource.odata_type]
        except KeyError as key:
            print "ERROR::{odata_id}: Unknown @odata.type {type}. Not able to process sub-elements" \
                .format(odata_id=odata_id, type=key)
            self._status = ValidationStatus.FAILED
            return

        try:
            self._process_properties(api_resource.body,
                                     type_definition,
                                     odata_id=odata_id)
        except Exception as err:
            import traceback
            print traceback.format_exc().replace('\n', '\nERROR::')

    def _process_properties(self, json_body, type_definition, odata_id, path=None):
        if path is None:
            path = Path()

        property_description_list = type_definition.navigation_properties.values() + type_definition.properties.values()

        self._append_additional_properties(property_description_list, json_body, type_definition, odata_id, path)

        for property_description in property_description_list:
            try:
                property_body = json_body[property_description.name]
            except KeyError:
                # this is discovery phase
                # any structure errors must be reported during subsequent analysis
                continue  # next property
            try:
                if property_description.is_collection:
                    for property_body_member in property_body:
                        self._process_property(property_description,
                                               property_body_member,
                                               odata_id,
                                               path)
                else:
                    self._process_property(property_description,
                                           property_body,
                                           odata_id,
                                           path)
            except TypeError:
                # this is discovery phase
                # any structure errors must be reported during subsequent analysis
                pass

    def _append_additional_properties(self, property_list, body, type_definition, odata_id, path):
        additionals = set(body.keys()) - set([property.name for property in property_list])
        # filter out special properties (properties that contain @ and #)
        additionals = filter(lambda property: not is_special_property(property), additionals)

        if len(additionals) > 0:
            if type_definition.allow_additional_properties:
                for property_name in additionals:
                    # process only objects
                    try:
                        property_value = body[property_name]
                        if isinstance(property_value, dict):
                            odata_type = match_dynamic_property(property_name, type_definition)
                            if odata_type is None:
                                try:
                                    odata_type = get_odata_type(property_value)
                                except KeyError as key:
                                    print "ERROR::{odata_id}#{path}: @odata.type not found in complex additional property" \
                                        .format(odata_id=odata_id, path=path.append(property_name))
                                    continue

                            adhoc_description = self.ad_hoc_type_definition(property_name, odata_type)
                            property_list.append(adhoc_description)
                    except KeyError:
                        pass
            else:
                print "ERROR::{odata_id}#{path}: Object of type {type}; unexpected properties: [{properties}]".format(
                    type=type_definition.name,
                    properties=", ".join(additionals),
                    odata_id=odata_id,
                    path=path
                )
                self._status = ValidationStatus.FAILED

    def ad_hoc_type_definition(self, property_name, odata_type):
        raw_soup = """
                    <Property Name="{name}" Type="{type}">
                    </Property>
                   """
        soup = BeautifulSoup(raw_soup.format(name=property_name, type=odata_type),
                             "lxml").find_all("property")[0]
        adhoc_description = Property(self._metadata_container, None, soup)
        return adhoc_description

    def _process_property(self, property_description, json_body, odata_id, path):
        if not json_body:
            return
        try:
            if property_description.type in self._metadata_container.entities.keys():
                return self._process_entity(property_description,
                                            json_body,
                                            path=path.append(property_description.name))
            elif self._metadata_container.types[property_description.type].type_category == MetadataTypeCategories.COMPLEX_TYPE:
                return self._process_complex_type(property_description,
                                                  json_body,
                                                  odata_id,
                                                  path=path.append(property_description.name))
        except KeyError as type:
            print "ERROR::{odata_id}#{path} : Unknown type {type}".format(
                odata_id=odata_id,
                path=path,
                type=property_description.type)
            pass

    def _process_entity(self, property_description, body, path):
        try:
            odata_id = body[".".join([ODATA, ID])]
        except KeyError:
            print "ERROR::{odata_id}#{path}: @odata.id expected in the resource body".format(odata_id=odata_id,
                                                                                             path=path)
            return

        try:
            if odata_id is not None:
                self._explore_resource(odata_id, property_description.type)
        except:
            import traceback
            print traceback.format_exc().replace('\n', '\nERROR::')
            self._status = ValidationStatus.FAILED

    def _process_complex_type(self, property_description, body, odata_id, path):
        try:
            # use override @odata.type if present.
            # At this stage do not verify if override type is consistent with type from property_description;
            # This will be validated in validate_get_responses test
            odata_type = get_odata_type(body)
        except KeyError:
            odata_type = property_description.type

        type_definition = self._metadata_container.types[odata_type]
        self._process_properties(body, type_definition, odata_id, path)
