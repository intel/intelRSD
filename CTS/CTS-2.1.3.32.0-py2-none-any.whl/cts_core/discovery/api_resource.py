"""
 * @section LICENSE
 *
 * @copyright
 * Copyright (c) 2016 Intel Corporation
 *
 * @copyright
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * @copyright
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * @copyright
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @section DESCRIPTION
"""

from collections import namedtuple
from cts_core.metadata.literals import *
from cts_core.commons.json_helpers import sanitize_odata_type

ALLOWABLE = "@Redfish.AllowableValues"
Location = namedtuple('Location', 'id parent_id')

class ApiResource:
    def __init__(self, json_body, expected_odata_type):
        self.odata_id = json_body.get(".".join([ODATA, ID]))
        self.odata_type = sanitize_odata_type(json_body.get(".".join([ODATA, TYPE])))
        if self.odata_type is None:
            self.odata_type = expected_odata_type
        self.expected_odata_type = sanitize_odata_type(expected_odata_type)
        self.body = json_body
        self.location = self._get_location(json_body)
        self.contains = self._get_contains(json_body)
        self.contained_by = self._get_contained_by(json_body)

        if not self.odata_id:
            print "WARNING:: @odata.id not present in %s. Setting 'None'." % json_body

        if not self.odata_type:
            print "WARNING:: @odata.type not present in %s. Setting 'None'." % json_body


    def _get_location(self, json_body):
        """
        :type json_body: dict
        """
        try:
            location_property = json_body[OEM][INTEL_RACKSCALE][LOCATION]
            location = Location(location_property[LOCATION_ID], location_property[PARENT_ID])
            return location
        except Exception:
            return None

    def _get_contains(self, json_body):
        """
        :type json_body: dict
        :rtype: list(str)
        """
        try:
            contains_property = json_body[LINKS][CONTAINS]
            contains = [m[ODATA_ID] for m in contains_property]
            return contains
        except Exception:
            return None

    def _get_contained_by(self, json_body):
        """
        :type json_body: dict
        :rtype: str
        """
        try:
            contained_by_property = json_body[LINKS][CONTAINED_BY]
            contained_by = contained_by_property[ODATA_ID]
            return contained_by
        except Exception:
            return None

    def get_value_from_path(self, variable_path):
        """
        :type variable_path: list[str or int]
        :rtype: *
        """
        partial_path = []
        value = self.body
        try:
            for path_element in variable_path:
                partial_path.append(str(path_element))
                if value is None:
                    partial_path_s = "->".join(partial_path)
                    #print "ERROR::Unable to access %s.%s" % (self.odata_id, partial_path_s)
                    raise KeyError(partial_path_s)
                value = value[path_element]
        except KeyError as key:
            raise KeyError(key)

        return value


    def get_allowable_from_path(self, variable_path):
        """
        :type variable_path: list[str or int]
        :rtype: *
        """
        try:
            value = self.get_value_from_path(variable_path[:-1])
            allowable_values_property = variable_path[-1] + ALLOWABLE
            allowable_values = value[allowable_values_property]
            return allowable_values
        except:
            return []
