"""
 * @section LICENSE
 *
 * @copyright
 * Copyright (c) 2016 Intel Corporation
 *
 * @copyright
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * @copyright
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * @copyright
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @section DESCRIPTION
"""
import os
import sys

from cts_core.commons.services import ServiceTypes
from cts_core.metadata.metadata_manager import MetadataManager
from cts_framework.build_information import BuildInformation

from cts_framework.helpers.python.test_script import TestScript

class CtsTestScript(TestScript):
    """
    base test case class
    """
    TIMEOUT = 60
    """:type: int"""
    DESCRIPTION = "Not specified"
    """:type: str"""
    CONFIGURATION_PARAMETERS = []
    """:type: list[TestCase.ConfigurationParameter]"""

    CONFIGURATION_PARAMETERS = [
        TestScript.ConfigurationParameter(parameter_name="ApiEndpoint",
                                          parameter_description="Endpoint to api that will be tested",
                                          parameter_type=str, is_required=True, parameter_default_value=None),
        TestScript.ConfigurationParameter(parameter_name="UseSSL",
                                          parameter_description="defines if CTS shall use ssl to communicate with api",
                                          parameter_type=str, is_required=True, parameter_default_value="No"),
        TestScript.ConfigurationParameter(parameter_name="CertificateCertFile",
                                          parameter_description="Path to file with certificate in PEM format",
                                          parameter_type=str, is_required=False, parameter_default_value=None),
        TestScript.ConfigurationParameter(parameter_name="CertificateKeyFile",
                                          parameter_description="Path to file with certificate key in PEM format",
                                          parameter_type=str, is_required=False, parameter_default_value=None),
        TestScript.ConfigurationParameter(parameter_name="User", parameter_type=str, is_required=False,
                                          parameter_description="If specified api will use specified user to authorize " +
                                                                "using basic auth",
                                          parameter_default_value=None),
        TestScript.ConfigurationParameter(parameter_name="Password",
                                          parameter_description="If specified api will use specified password to " +
                                                                "authorize using basic auth", parameter_type=str,
                                          is_required=False, parameter_default_value=None),
        TestScript.ConfigurationParameter(parameter_name="IgnoreTypes",
                                          parameter_description="List (comma separated) of fully qualified types. " +
                                                                "Entities, properties of that types will not be validated.",
                                          parameter_type=str, is_required=False, parameter_default_value=""),
        TestScript.ConfigurationParameter(parameter_name="MapTypes",
                                          parameter_description="List (comma separated) of pairs T1:T2, " +
                                                                "where T1 is fully qualified type that is unknown to CTS " +
                                                                "and T2 is fully qualified type that is known to CTS. " +
                                                                "CTS will use T2 to validate instances of T1.",
                                          parameter_type=str, is_required=False, parameter_default_value=""),
        TestScript.ConfigurationParameter(parameter_name="ServiceTypeOverride",
                                          parameter_description="List (comma separated) of REST services that are available on the API endpoint." +
                                                                "Possible values are: %s" % ServiceTypes.list_s(),
                                          parameter_type=str, is_required=False, parameter_default_value="")

    ]
    """:type: list[TestCase.ConfigurationParameter]"""


    @classmethod
    def service_cli(cls):
        all_params = cls.CONFIGURATION_PARAMETERS + \
                     super(CtsTestScript, cls).CONFIGURATION_PARAMETERS + \
                     CtsTestScript.CONFIGURATION_PARAMETERS

        #remove duplicates
        seen = set()
        cls.CONFIGURATION_PARAMETERS = [param for param in all_params if not (param in seen or seen.add(param))]

        super(CtsTestScript, cls).service_cli()

    def before_run(self):
        self._parse_ignore_types()
        self._parse_map_types()
        self._parse_service_types_override()

    def _parse_service_types_override(self):
        self._service_types_override = {service for service in
                                        (type.strip() for type in self.configuration.ServiceTypeOverride.split(","))
                                        if len(service) > 0
                                        }

        illegal = self._service_types_override - set(ServiceTypes.all())
        if len(illegal) > 0:
            print "ERROR::Invalid service types specified in ServiceTypeOverride configuration parameter: %s" \
                  % ", ".join(illegal)
        self._service_types_override -= illegal

        if len(self._service_types_override) > 0:
            print "WARNING::Test was designed to be run against metadata for: %s, but user declared that service supports: %s" \
                  % (self.registered_services_s(), ", ".join(self._service_types_override))

    def _parse_map_types(self):
        if self.configuration.MapTypes:
            try:
                self._map_types = {from_type: to_type for (from_type, to_type) in \
                                   ((pair[0].strip(), pair[1].strip()) for pair in \
                                    (pair.split(':') for pair in self.configuration.MapTypes.split(',')) \
                                    )
                                   if len(from_type) > 0 and len(to_type) > 0
                                   }
                if len(self._map_types) > 0:
                    print "WARNING::CTS was configured to use the following type mappings to validate instances of unknown types:"
                    for from_type in self._map_types:
                        print "WARNING::\t- %s:%s" % (from_type, self._map_types[from_type])
            except Exception as error:
                print "ERROR::Error while parsing 'MapTypes' configuration parameter. error = %s" % error
        else:
            self._map_types = dict()

    def _parse_ignore_types(self):
        self._ignore_types = set([type.strip() for type in self.configuration.IgnoreTypes.split(",")])
        if len(self._ignore_types) > 0:
            print "WARNING::CTS was configured to skip properties and entities of the following types:"
            for ignore_type in self._ignore_types:
                print "WARNING::\t- %s" % ignore_type

    def _load_metadata(self):
        to_load = self.registered_services if len(self._service_types_override) == 0 else list(self._service_types_override)
        qualifiers = list(to_load)
        for qualifier in to_load:
            underscore = qualifier.find('_')
            if -1 != underscore:
                qualifiers.append(qualifier[:underscore])

        print "MESSAGE::Loading metadata for services: %s, using qualifiers: %s" \
              % (", ".join(to_load), ", ".join(qualifiers))

        service_to_metadata = {
            ServiceTypes.PODM_1_2 : BuildInformation.RACKSCALE_1_2_PODM_SCHEMA,
            ServiceTypes.PSME_1_2: BuildInformation.RACKSCALE_1_2_PSME_SCHEMA,
            ServiceTypes.SS_1_2: BuildInformation.RACKSCALE_1_2_SS_SCHEMA,
            ServiceTypes.RMM_1_2: BuildInformation.RACKSCALE_1_2_RMM_SCHEMA,
            ServiceTypes.PODM_2_1: BuildInformation.RACKSCALE_2_1_PODM_SCHEMA,
            ServiceTypes.PSME_2_1: BuildInformation.RACKSCALE_2_1_PSME_SCHEMA,
            ServiceTypes.SS_2_1: BuildInformation.RACKSCALE_2_1_SS_SCHEMA,
            ServiceTypes.RMM_2_1: BuildInformation.RACKSCALE_2_1_RMM_SCHEMA,
        }

        try:
            metadata = map(lambda service: service_to_metadata[service], to_load)
        except AttributeError as error:
            print "ERROR::Internal error. Service not registered? Did you call RegisterService? %s" % error
            sys.exit(-1)
        except KeyError as error:
            print "ERROR::Internal error. Don't know what metadata use for service. %s" % error

        metadata_manager = MetadataManager(ignore_types=self.ignore_types, map_types=self.map_types)
        metadata_container = metadata_manager.read_metadata(qualifiers, *metadata)
        metadata_container.print_types()
        return metadata_container

    def registered_services_s(self):
        return ', '.join(self.registered_services)

    @property
    def metadata_container(self):
        if not hasattr(self, "_metadata_container"):
            self._metadata_container = self._load_metadata()
        return self._metadata_container

    @property
    def ignore_types(self):
        if not hasattr(self, "_ignore_types"):
            self._ignore_types = set()
        return self._ignore_types

    @property
    def map_types(self):
        if not hasattr(self, "_map_types"):
            self._map_types = dict()
        return self._map_types
