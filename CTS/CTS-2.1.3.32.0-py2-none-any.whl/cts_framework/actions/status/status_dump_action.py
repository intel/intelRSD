"""
 * @section LICENSE
 *
 * @copyright
 * Copyright (c) 2016 Intel Corporation
 *
 * @copyright
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * @copyright
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * @copyright
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @section DESCRIPTION
"""

from cts_framework.actions.action import Action
from cts_framework.actions.status.results_formatters.csv_formatter import CsvFormatter
from cts_framework.actions.status.results_formatters.html_formatter import HtmlFormatter
from cts_framework.actions.status.results_formatters.text_formatter import TextFormatter

HTML_FORMAT = "html"
TEXT_FORMAT = "text"
CSV_FORMAT = "csv"


class StatusDumpAction(Action):
    ACTION = "dump"
    PARAM_NAME = "STATUS_TYPE"

    def fill_parser_arguments(self):
        self.parser.add_argument("test_run_id", type=str, nargs=1, default=None,
                                 help="IDs of test run that results will be dumped")
        self.parser.add_argument("-o", "--output_format", type=str, nargs=1, required=True,
                                 choices=[HTML_FORMAT, TEXT_FORMAT, CSV_FORMAT])

    def process_action(self, configuration):
        run_id = configuration.test_run_id[0]
        output_format = configuration.output_format[0]
        if output_format == HTML_FORMAT:
            self.serve_html_format(run_id)
        else:
            try:
                # TODO: instead of print results shall be moved to file
                {TEXT_FORMAT: TextFormatter, CSV_FORMAT: CsvFormatter}[
                    output_format]\
                    ().print_results(run_id)
            except AttributeError:
                print "Results for test run #%s not found" % run_id

    def serve_html_format(self, run_id):
        HtmlFormatter().save_results(run_id)
