"""
 * @section LICENSE
 *
 * @copyright
 * Copyright (c) 2016 Intel Corporation
 *
 * @copyright
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * @copyright
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * @copyright
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @section DESCRIPTION
"""
from cts_framework.actions.status.results_formatters.formatter import Formatter
from cts_framework.db.dao.run_dao import RunDAO
from cts_framework.build_information import BuildInformation
from cts_framework.helpers.python.message_level import MessageLevel
from cts_framework.commons.enums import LoggingLevel
from cts_framework.helpers.python.result_status import ResultStatus
from cts_framework.db.dao.case_dao import CaseDAO
from cts_framework.db.dao.message_dao import MessageDAO
from cts_framework.db.dao.script_dao import ScriptDAO
from os import makedirs
from os.path import exists
import pkg_resources
from distutils.dir_util import copy_tree as copytree

class HtmlFormatter(Formatter):
    REPORT_FOLDER = "cts_report"
    PASSED = "PASSED"
    FAILED = "FAILED"
    HEADER = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <link rel="stylesheet" href="./static/style.css" />
        <link rel="stylesheet" href="./static/css/bootstrap.css">
    </head>

    <body>
        <nav class="navbar navbar-default header">
            <div class="container-fluid header">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">
                        <img src="static/intel-logo-white.png" alt="Intel" width="50px" />
                    </a>
                </div>
                <h2>Intel Rack Scale Design</h2>
            </div>
        </nav>
        <div class="page-header col-md-12">
            <h1> Intel Conformance Test Suite <small>  report</small></h1>
        </div>
            """

    FOOTER = """
        <div class="footer">
            <ol class="breadcrumb">
                <li>Tests were performed using CTS in version </li>
                <li><i>{version}</i></li>
            </ol>
        </div>

    </body>

    <!--Custom scripts-->
    <script src="./static/scripts.js"></script>

    </html>
        """.format(version=BuildInformation.BUILD_VERSION)

    RESULT_RUN_REPORT = """
        <div class="col-md-12">
            <div id="panelHeading" class="panel ">
                <div class="panel-heading">
                    <h2>Overall status <span id="overallStatus"><b>{status}</b></span> </h2>
                </div>

                <h2 class="header-h2">Passing rate  <span id="passingRateBadge" class="badge ">{passed}/{total}</span></h2>

                <div class="header-space">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">Executed test scripts:</h3>
                        </div>

                        <ul class="list-group">
                            {test_script_result}
                        </ul>
                    </div>
                </div>

            </div>
        </div>
        </div>
    """

    RESULT_SCRIPT_REPORT = """
        <div class="col-md-12">
            <!-- This class is managed by script PanelColorChange() -->
            <div id="panelHeading" class="panel">
                <div class="panel-heading">
                    <h2>Overall status <span id="overallStatus"><b>{status}</b></span> </h2>
                </div>

                <h2 class="header-h2">Passing rate <span id="passingRateBadge" class="badge ">{passed}/{total}</span></h2>

                <div class="header-space">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">Executed test scripts:</h3>
                        </div>

                        <ul class="list-group">
                            {test_script_result}
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    """

    RESULT_SAVE_CASE_RESULT = """
        <div class="col-md-12">
            <div id="panelHeading" class="panel">
                <div class="panel-heading">
                    <h2>Overall status <span id="overallStatus"><b></b></span> </h2>
                </div>

                <h2 class="header-h2">
                  <small>
                    /neutral  <span id="successBadge" class="badge">{successBadge}</span>
                    /debug <span id="debugBadge" class="badge">{debugBadge}</span>
                    /warnings  <span id="warningBadge" class="badge">{warningsBadge}</span>
                    /errors  <span id="errorBadge" class="badge">{errorsBadge}</span>

                  </small>
                </h2>
                <div class="header-space">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">Logs from case execution</h3>
                        </div>

                        <ul class="list-group">
                            {test_script_result}
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    """

    def __init__(self):
        NEEDED_FILES = ("scripts.js", "style.css", "intel-logo-white.png")
        HTML_TEMPLATE_DIR = 'html_template_files'
        HTML_STATIC = '/'.join((HtmlFormatter.REPORT_FOLDER, 'static'))

        if not exists(HTML_STATIC):
            makedirs(HTML_STATIC)

        try:
            import pip
            dist = None
            for d in pip.get_installed_distributions():
                if d.project_name == 'Flask-Bootstrap':
                    dist = d.location

            project_path = "/".join([dist, "flask_bootstrap", "static"])
            copytree(project_path, HTML_STATIC)

        except ImportError:
            print "CTS_ERROR:: %s" % ImportError

        try:
            for file in NEEDED_FILES:
                if not exists('/'.join((HTML_STATIC, file))):
                    resource_package = __name__
                    resource_path = '/'.join((HTML_TEMPLATE_DIR, file))

                    template = pkg_resources.resource_string(resource_package, resource_path)
                    with open('/'.join((HTML_STATIC, file)), 'w') as resource:
                        resource.write(template)

        except IOError as e:
            print("CTS can't create file or directory. Do you've appropriate permissions?")


    def save_results(self, run_id):
        status, passed, total = RunDAO.get_overall_run_result(run_id)
        text_status = HtmlFormatter.PASSED if status else HtmlFormatter.FAILED

        script_execution_ids = ScriptDAO.get_scripts_execution_ids_for_run(run_id)

        test_scripts_result = ""
        for script_execution_id in script_execution_ids:
            script_execution_details = ScriptDAO.get_script_execution_details(script_execution_id)

            self.save_script_results(script_execution_id)

            overall, passed, total = ScriptDAO.get_script_execution_statistics(script_execution_id)
            if passed == total:
                li_style = "success"
                glyphicon = "ok"
            elif overall:
                li_style = "warning"
                glyphicon = "exclamation-sign"
            else:
                li_style = "danger"
                glyphicon = "remove"

            test_scripts_result += "<li class='list-group-item list-item-%s'><a class='report' href='%s_script_report.html'><span class='report glyphicon glyphicon-%s'></span>  %s</a></li>" % (
                li_style, script_execution_details.id, glyphicon, script_execution_details.script_path)

        resultRunReport = HtmlFormatter.RESULT_RUN_REPORT.format(status=text_status, passed=passed, total=total,
                                                   test_script_result=test_scripts_result)

        with open(HtmlFormatter.REPORT_FOLDER + "/" + "%s_run_report.html" % run_id, "w") as report:
            report.write("{header}{resultRunReport}{footer}".format(
                header=HtmlFormatter.HEADER,
                resultRunReport=resultRunReport,
                footer=HtmlFormatter.FOOTER))


    def save_script_results(self, script_execution_id):
        cases_execution_ids = CaseDAO.get_cases_execution_ids_for_script_execution(script_execution_id)
        status, passed, total = ScriptDAO.get_script_execution_statistics(script_execution_id)

        text_status = HtmlFormatter.PASSED if status else HtmlFormatter.FAILED
        test_script_result = ""

        for case_execution_id in cases_execution_ids:
            case_execution_details = CaseDAO.get_case_execution_details(case_execution_id)
            if case_execution_details.status == ResultStatus.PASSED:
                li_style = "success"
                glyphicon = "ok"
            elif case_execution_details.status in [ResultStatus.FAILED, ResultStatus.TIMEOUT]:
                li_style = "warning"
                glyphicon = "exclamation-sign"
            elif case_execution_details.status in [ResultStatus.BLOCKED, ResultStatus.UNKNOWN]:
                li_style = "danger"
                glyphicon = "remove"
            else:
                li_style = "neutral"
                glyphicon = "minus"

            test_script_result += "<li class='list-group-item list-item-%s'><a class='report' href='%s_case_results.html'><span class='report glyphicon glyphicon-%s'></span>  %s</a></li>" % (
                li_style, case_execution_details.id, glyphicon, case_execution_details.name)

            self.save_case_result(case_execution_id)

        resultRunReport = HtmlFormatter.RESULT_SCRIPT_REPORT.format(status=text_status,
                                                                    passed=passed,
                                                                    total=total,
                                                                    test_script_result=test_script_result)

        with open(HtmlFormatter.REPORT_FOLDER + "/" + "%s_script_report.html" % script_execution_id, "w") as report:
            report.write("{header}{resultRunReport}{footer}".format(
                header=HtmlFormatter.HEADER,
                resultRunReport=resultRunReport,
                footer=HtmlFormatter.FOOTER
            ))


    def save_case_result(self, case_execution_id):
        result = ""
        countPerStatus = {'neutral': 0, 'debug': 0, 'warning': 0, 'error': 0}
        for message in MessageDAO.get_messages_for_case_execution(case_execution_id):
            if LoggingLevel.METADATA == message.message_level:
                ok, status_code, request, response = self.try_retrieve_request_from_metadata(message.message_text)
                if ok:
                    li_style = "neutral"

                    result += "<li class='list-group-item list-item-{li_style}'> <div><br>Request:<br>".format(
                        li_style=li_style)
                    result += "<pre>{message}</pre>\n". \
                        format(message=request.replace("\n", "<br>"))
                    result += "</div>"

                    result += "<div style='{li_style}'><br>Response:<br>".format(li_style=li_style)
                    result += "<pre>{message}</pre>\n". \
                        format(message=response.replace("\n", "<br>"))
                    result += "</div></li>"
            else:
                if message.message_level == MessageLevel.ERROR:
                    countPerStatus['error'] += 1
                    li_style = "danger"
                    glyphicon = "remove"
                elif message.message_level == MessageLevel.WARNING:
                    countPerStatus['warning'] += 1
                    li_style = "warning"
                    glyphicon = "exclamation-sign"
                elif message.message_level == MessageLevel.DEBUG:
                    countPerStatus['debug'] += 1
                    li_style = "neutral"
                    glyphicon = "asterisk"
                else:
                    countPerStatus['neutral'] += 1
                    li_style = "default"
                    glyphicon = "unchecked"

                result += "<li class='list-group-item list-item-{li_style}'><span class='report glyphicon glyphicon-{glyphicon}'></span>{datetime} - {message}</li>\n". \
                    format(li_style=li_style,
                           glyphicon=glyphicon,
                           datetime=message.message_datetime,
                           message=message.message_text.replace("\n", "<br>"))

        resultRunReport = HtmlFormatter.RESULT_SAVE_CASE_RESULT.format(test_script_result=result,
                                                                       successBadge=countPerStatus['neutral'],
                                                                       debugBadge=countPerStatus['debug'],
                                                                       warningsBadge=countPerStatus['warning'],
                                                                       errorsBadge=countPerStatus['error']
                                                                       )

        with open(HtmlFormatter.REPORT_FOLDER + "/" + "%s_case_results.html" % case_execution_id, "w") as report:
            report.write("{header}{resultRunReport}{footer}".format(
                header=HtmlFormatter.HEADER,
                resultRunReport=resultRunReport,
                footer=HtmlFormatter.FOOTER))
