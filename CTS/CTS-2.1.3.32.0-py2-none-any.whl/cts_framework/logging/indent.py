def indent():
    return "    " * Indent.indent

class Indent:
    indent = 0

    @classmethod
    def indent_right(cls):
        Indent.indent += 1

    @classmethod
    def indent_reset(cls):
        Indent.indent = 0
